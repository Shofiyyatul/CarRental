<?= $this->extend('layout/app') ?>

<?= $this->section('content') ?>

    <div class="panel panel-info">
        <div class="panel-heading"><h3 class="text-center">Detail Transaksi</h3></div>
        <div class="panel-body">
            <table class="table table-hover">
                <tbody>
                    <tr>
                        <th>Mobil</th>
                        <td>: <?=$transaksi['nama_mobil']?></td>
                    </tr>
                    <tr>
                        <th>Lama</th>
                        <td>: <?=$transaksi['lama']?> Hari</td>
                    </tr>
                    <tr>
                        <th>Jaminan</th>
                        <td>: <?=$transaksi['jaminan']?></td>
                    </tr>
                    <tr>
                        <th>Total</th>
                        <td>: Rp.<?=number_format($transaksi['total_harga'])?>,-</td>
                    </tr>
                    <tr>
                        <th>Tanggal Sewa</th>
                        <td>: <?=date("d-m-Y H:i:s", strtotime($transaksi['tgl_sewa']))?></td>
                    </tr>
                    <tr>
                        <th>Tanggal Ambil</th>
                        <td>: <?=($transaksi['tgl_ambil']) ? date("d-m-Y H:i:s", strtotime($transaksi['tgl_ambil'])) : "<b>Belum</b>"?></td>
                    </tr>
                    <tr>
                        <th>Tanggal Kembali</th>
                        <td>: <?=($transaksi['tgl_kembali']) ? date("d-m-Y H:i:s", strtotime($transaksi['tgl_kembali'])) : "<b>Belum</b>"?></td>
                    </tr>
                    <tr>
                        <th>Jatuh Tempo</th>
                        <td>: <?=date("d-m-Y H:i:s", strtotime($transaksi['jatuh_tempo']))?></td>
                    </tr>
                    <tr>
                        <th>Konfirmasi</th>
                        <td>: <span class="label label-<?=($transaksi['konfirmasi']) ? "success" : "danger"?>"><?=($transaksi['konfirmasi']) ? "Sudah" : "Belum"?></span></td>
                    </tr>
                    <tr>
                        <th>Kembali</th>
                        <td>: <span class="label label-<?=($transaksi['status']) ? "success" : "danger"?>"><?=($transaksi['status']) ? "Sudah" : "Belum"?></span></td>
                    </tr>
                    <tr>
                        <th>Pembatalan</th>
                        <td>: <span class="label label-<?=($transaksi['pembatalan']) ? "danger" : "success"?>"><?=($transaksi['pembatalan']) ? "Ya" : "Tidak"?></span></td>
                    </tr>
                    <tr class="hidden-print">
                        <th></th>
                        <td> &nbsp;
                            <?php if (!$transaksi['konfirmasi']): ?>
                                <a href="?page=konfirmasi&id=<?= $transaksi['id_transaksi'] ?>" class="btn btn-primary">Konfirmasi Sekarang</a>
                            <?php endif ?>
                            <?php if ($transaksi['konfirmasi'] == 1 AND $transaksi['tgl_kembali'] == NULL AND $transaksi["pembatalan"] != 1): ?>
                                <a href="?page=perpanjang&id=<?= $transaksi['id_transaksi'] ?>" class="btn btn-success">Perpanjang Sekarang</a>
                            <?php endif ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="panel-footer hidden-print ">
            <a onClick="window.print();return false" class="btn btn-primary"><i class="glyphicon glyphicon-print"></i></a>
        </div>
    </div>

<?= $this->endSection() ?>