<?= $this->extend('layout/app') ?>

<?= $this->section('content') ?>

    <div class="row">
        <div class="col-md-4 hidden-print">
            <div class="panel panel-info">
                <div class="panel-heading"><h3 class="text-center">Profil</h3></div>
                <div class="panel-body">
                    <form>
                        <div class="form-group">
                            <label for="nama">Nama Lengkap</label>
                            <input disabled="on" type="text" name="nama" class="form-control" value="<?=$pelanggan['nama']?>">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input disabled="on" type="email" name="email" class="form-control" value="<?=$pelanggan['email']?>">
                        </div>
                        <div class="form-group">
                            <label for="no_telp">Telpon</label>
                            <input disabled="on" type="text" name="no_telp" class="form-control" value="<?=$pelanggan['no_telp']?>">
                        </div>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input disabled="on" type="text" name="username" class="form-control" value="<?=$pelanggan['username']?>">
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <input disabled="on" type="text" name="alamat" class="form-control" value="<?=$pelanggan['alamat']?>">
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-8">
            <div class="row">
                <div class="panel panel-info">
                    <div class="panel-heading"><h3 class="text-center">Riwayat Transaksi</h3></div>
                    <div class="panel-body">
                        <?php $no = 1; ?>
                            <table class="table table-hover">
                                <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Total</th>
                                    <th>Lama</th>
                                    <th>Jaminan</th>
                                    <th>Tanggal</th>
                                    <th>Jatuh Tempo</th>
                                    <th class="hidden-print"></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($transaksi as $rt): ?>
                                    <tr>
                                        <td><?=$no++?></td>
                                        <td>Rp.<?=number_format($rt['total_harga'])?>,-</td>
                                        <td><?=$rt['lama']?> Hari</td>
                                        <td><?=$rt['jaminan']?></td>
                                        <td><?=date("d-m-Y H:i:s", strtotime($rt['tgl_sewa']))?></td>
                                        <td><?=date("d-m-Y H:i:s", strtotime($rt['jatuh_tempo']))?></td>
                                        <td class="hidden-print">
                                            <div class="btn-group">
                                                <?php if (!$rt['konfirmasi'] AND !$rt["pembatalan"]): ?>
                                                    <a href="<?= base_url('transaksi/'.$rt['id'].'/konfirmasi') ?>" class="btn btn-success btn-xs">Konfirmasi</a>
                                                <?php endif ?>
                                                <a href="<?= base_url('transaksi/'.$rt['id'].'/detail') ?>" class="btn btn-info btn-xs">Detail</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                    </div>
                    <div class="panel-footer hidden-print ">
                        <a onClick="window.print();return false" class="btn btn-primary"><i class="glyphicon glyphicon-print"></i></a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="panel panel-info">
                    <div class="panel-heading"><h3 class="text-center">Riwayat Denda</h3></div>
                    <div class="panel-body">
                    <?php $no = 1; ?>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Jaminan</th>
                                <th>Tanggal Ambil</th>
                                <th>Tanggal Kembali</th>
                                <th>Total Harga</th>
                                <th>Total Denda</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($denda as $rd): ?>
                            <tr>
                                <td><?=$no++?></td>
                                <td><?=$rd['jaminan']?></td>
                                <td><?=date("d-m-Y H:i:s", strtotime($rd['tgl_ambil']))?></td>
                                <td><?=date("d-m-Y H:i:s", strtotime($rd['tgl_kembali']))?></td>
                                <td>Rp.<?=number_format($rd['total_harga'])?>,-</td>
                                <td>Rp.<?=number_format($rd['denda'])?>,-</td>
                                <td>
                                    <a href="<?= base_url('transaksi/'.$rd['id'].'/detail') ?>" class="btn btn-warning btn-xs">Lihat Transaksi</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                    <div class="panel-footer hidden-print ">
                        <a onClick="window.print();return false" class="btn btn-primary"><i class="glyphicon glyphicon-print"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?= $this->endSection() ?>
