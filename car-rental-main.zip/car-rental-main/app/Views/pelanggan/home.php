<?= $this->extend('layout/app') ?>

<?= $this->section('content') ?>

    <div class="page-header">
        <h2><img src="assets/img/logo.png" width="10%" alt="" srcset="">SEWA MOBIL</h2>
    </div>
    <div class="row">
        <?php foreach($mobil as $m) : ?>
            <div class="col-xs-6 col-md-3">
                <div class="thumbnail">
                    <a href="assets/img/mobil/<?=$m['gambar']?>" class="fancybox">
                        <img src="assets/img/mobil/<?=$m['gambar']?>" style="height:250px; width:100%">
                    </a>
                    <div class="caption text-center">
                        <h4><?=$m["nama_mobil"]?></h4>
                        <h5>Rp.<?=number_format($m["harga"], '0', '.', '.')?>,- <?=$m["nama_mobil"]?> - <?=$m["merk"]?></h5>
                        <h6><?=$m["no_mobil"]?></h6>
                        <span class="label label-<?=($m['status']) ? "success" : "danger" ?>"><?=($m['status']) ? "Tersedia" : "Tidak Tersedia" ?></span>
                        <p>
                            <br>
                            <a href="<?=($m['status']) ? base_url('transaksi/'.$m['id'].'/sewa') : "#" ?>" class="btn btn-primary" <?=($m['status']) ?: "disabled" ?>>Sewa Sekarang!</a>
                        </p>
                    </div>
                </div>
            </div>
        <?php endforeach ?>
    </div>

    <script type="text/javascript">
        $(document).ready(function(){
            $(".fancybox").fancybox({
                openEffect  : 'none',
                closeEffect : 'none',
                iframe : {
                    preload: false
                }
            });
            $(".various").fancybox({
                maxWidth    : 800,
                maxHeight    : 600,
                fitToView    : false,
                width        : '70%',
                height        : '70%',
                autoSize    : false,
                closeClick    : false,
                openEffect    : 'none',
                closeEffect    : 'none'
            });
            $('.fancybox-media').fancybox({
                openEffect  : 'none',
                closeEffect : 'none',
                helpers : {
                    media : {}
                }
            });
        });
    </script>

<?= $this->endSection() ?>
