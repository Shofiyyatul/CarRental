<?= $this->extend('layout/app') ?>

<?= $this->section('content') ?>

    <div class="panel panel-info">
        <div class="panel-heading"><h3 class="text-center">Transaksi Berhasil</h3></div>
        <div class="panel-body">
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>Nama Pelanggan</th>
                    <td>: <?= session()->get('nama') ?></td>
                </tr>
                <tr>
                    <th>Email</th>
                    <td>: <?= session()->get('email') ?></td>
                </tr>
                <tr>
                    <th>Harga Sewa</th>
                    <td>: Rp.<?=number_format($harga["harga_sewa"])?>,-/hari</td>
                </tr>
                <tr>
                    <th>Harga Supir</th>
                    <td>: Rp.<?=number_format($harga['harga_supir'])?>,-/hari</td>
                </tr>
                <tr>
                    <th>Lama Sewa</th>
                    <td>: <?=$transaksi["lama"]?> hari</td>
                </tr>
                <tr>
                    <th>Tanggal Ambil</th>
                    <td>: <?=date("d-m-Y H:i:s", strtotime($transaksi['tgl_ambil']))?></td>
                </tr>
                <tr>
                    <th>Total Bayar</th>
                    <td>: Rp.<?=number_format($transaksi['total_harga'])?>,-</td>
                </tr>
                <tr>
                    <th>Jatuh Tempo pembayaran</th>
                    <td>: <?=date("d-m-Y H:i:s", strtotime($transaksi['jatuh_tempo']))?></td>
                </tr>
                <tr>
                    <th>Jaminan</th>
                    <td>: <?= $transaksi['jaminan'] ?></td>
                </tr>
                </thead>
            </table>
            <hr>
            <h3>Terimakasih</h3>
            <p>
                Transaksi pembelian anda telah berhasil<br>
                Silahkan anda membayar tagihan anda dengan cara transfer via Bank BRI di nomor Rekening : <br>
                <strong>(0986-01-025805-53-8 a/n SEWA MOBIL)</strong> untuk menyelesaikan pembayaran. dan untuk uang muka minimal setengah dari harga sewa.
            </p>
            <p>
                Jika anda sudah melakukan transfer silahkan anda melakukan konfirmasi pembayaran dengan mengunjungi halaman profil akun anda lalu tekan tombol. <i><b>Lihat Profil</b></i>.
            </p>
            <p> Batas Konfirmasi 3 jam, jika lebih dari 3 jam anda tidak melakukan konfirmasi maka sistem akan membatalkan pesanan secara otomatis.
            </p>
        </div>
        <div class="panel-footer">
            <a href="<?= base_url('profil') ?>" class="btn btn-primary btn-sm">Lihat Profil</a>
        </div>
    </div>

<?= $this->endSection() ?>