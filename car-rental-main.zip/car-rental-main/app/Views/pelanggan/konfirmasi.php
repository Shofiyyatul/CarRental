<?= $this->extend('layout/app') ?>

<?= $this->section('content') ?>

    <div class="panel panel-info">
        <div class="panel-heading"><h3 class="text-center">Konfirmasi Pembayaran</h3></div>
        <div class="panel-body">
            <form action="<?= base_url('transaksi/'.$id.'/konfirmasi') ?>" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="bukti">Bukti Pembayaran</label>
                    <input type="file" name="bukti" class="form-control">
                </div>
                <button type="submit" class="btn btn-info btn-block">Konfirmasi</button>
            </form>
        </div>
    </div>

<?= $this->endSection() ?>
