<?= $this->extend('layout/admin') ?>

<?= $this->section('content') ?>

    <div class="row">
        <div class="col-md-4 hidden-print">

            <div class="panel panel-<?= ($update) ? "warning" : "info" ?>">
                <div class="panel-heading"><h3 class="text-center"><?= ($update) ? "EDIT" : "TAMBAH" ?></h3></div>
                <div class="panel-body">
                    <form action="<?= ($update) ? base_url('admin/pelanggan/'.$pelangganDetail["id"].'/update') : base_url('admin/pelanggan/create') ?>" method="POST">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" name="nama" class="form-control" <?= ($update) ? 'value="'.$pelangganDetail["nama"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="nama">No KTP</label>
                            <input type="text" name="no_ktp" class="form-control" <?= ($update) ? 'value="'.$pelangganDetail["no_ktp"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="no_telp">Telp</label>
                            <input type="text" name="no_telp" class="form-control" <?= ($update) ? 'value="'.$pelangganDetail["no_telp"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" name="email" class="form-control" <?= ($update) ? 'value="'.$pelangganDetail["email"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <input type="text" name="alamat" class="form-control" <?= ($update) ? 'value="'.$pelangganDetail["alamat"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" name="username" class="form-control" <?= ($update) ? 'value="'.$pelangganDetail["username"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" name="password" class="form-control">
                            <?php if ($update): ?>
                                <span class="help-block">*) Kosongkan jika tidak diubah</span>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="btn btn-<?= ($update) ? "warning" : "info" ?> btn-block">Simpan</button>
                        <?php if ($update): ?>
                            <a href="<?= base_url('admin/pelanggan') ?>" class="btn btn-info btn-block">Batal</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="panel panel-info">
                <div class="panel-heading"><h3 class="text-center">DAFTAR PELANGGAN</h3></div>
                <div class="panel-body">
                    <table class="table table-condensed">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Telp</th>
                            <th>Email</th>
                            <th>Username</th>
                            <th>Alamat</th>
                            <th></th>
                            <th class="hidden-print"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($pelanggan as $p): ?>
                                <tr>
                                    <td><?=$no++?></td>
                                    <td><?=$p['nama']?></td>
                                    <td><?=$p['no_telp']?></td>
                                    <td><?=$p['email']?></td>
                                    <td><?=$p['username']?></td>
                                    <td><?=$p['alamat']?></td>
                                    <td>
                                    <td class="hidden-print">
                                        <div class="btn-group">
                                            <a href="<?= base_url('admin/pelanggan/'.$p['id'].'/edit') ?>" class="btn btn-warning btn-xs">Edit</a>
                                            <a href="<?=base_url('admin/pelanggan/'.$p['id'].'/destroy')?>" class="btn btn-danger btn-xs">Hapus</a>
                                        </div>
                                    </td>
                                </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="panel-footer hidden-print">
                    <a onClick="window.print();return false" class="btn btn-primary"><i class="glyphicon glyphicon-print"></i></a>
                </div>
            </div>
        </div>
    </div>

<?= $this->endSection() ?>
