<?= $this->extend('layout/admin') ?>

<?= $this->section('content') ?>

    <div class="row">
        <div class="col-md-4 hidden-print">
            <div class="panel panel-<?= ($update) ? "warning" : "info" ?>">
                <div class="panel-heading"><h3 class="text-center"><?= ($update) ? "EDIT" : "TAMBAH" ?></h3></div>
                <div class="panel-body">
                    <form action="<?= ($update) ? base_url('admin/supir/'.$supirDetail["id"].'/update') : base_url('admin/supir/create') ?>" method="POST">
                        <div class="form-group">
                            <label for="nama">Nama</label>
                            <input type="text" name="nama" class="form-control" <?= ($update) ? 'value="'.$supirDetail["nama"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="telp">Telp</label>
                            <input type="text" name="telp" class="form-control" <?= ($update) ? 'value="'.$supirDetail["telp"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="alamat">Alamat</label>
                            <input type="text" name="alamat" class="form-control" <?= ($update) ? 'value="'.$supirDetail["alamat"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select class="form-control" name="status">
                                <option>---</option>
                                <option value="0" <?= (!$update) ?: (($supirDetail["status"] != 0) ?: 'selected="on"') ?>>Tidak Tersedia</option>
                                <option value="1" <?= (!$update) ?: (($supirDetail["status"] != 1) ?: 'selected="on"') ?>>Tersedia</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-<?= ($update) ? "warning" : "info" ?> btn-block">Simpan</button>
                        <?php if ($update): ?>
                            <a href="?page=supir" class="btn btn-info btn-block">Batal</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="panel panel-info">
                <div class="panel-heading"><h3 class="text-center">DAFTAR SUPIR</h3></div>
                <div class="panel-body">
                    <table class="table table-condensed">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Telp</th>
                            <th>Alamat</th>
                            <th>Status</th>
                            <th class="hidden-print"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($supir as $s): ?>
                                <tr>
                                    <td><?=$no++?></td>
                                    <td><?=$s['nama']?></td>
                                    <td><?=$s['telp']?></td>
                                    <td><?=$s['alamat']?></td>
                                    <td><span class="label label-<?=($s['status']) ? "success" : "danger" ?>"><?=($s['status']) ? "Tersedia" : "Tidak Tersedia" ?></span></td>
                                    <td class="hidden-print">
                                        <div class="btn-group">
                                            <a href="<?= base_url('admin/supir/'.$s['id'].'/edit') ?>" class="btn btn-warning btn-xs">Edit</a>
                                            <a href="<?=base_url('admin/supir/'.$s['id'].'/destroy')?>" class="btn btn-danger btn-xs">Hapus</a>
                                        </div>
                                    </td>
                                </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="panel-footer hidden-print">
                    <a onClick="window.print();return false" class="btn btn-primary"><i class="glyphicon glyphicon-print"></i></a>
                </div>
            </div>
        </div>
    </div>

<?= $this->endSection() ?>
