<?= $this->extend('layout/admin') ?>

<?= $this->section('content') ?>

    <div class="row">
        <div class="col-md-4 hidden-print">
            <div class="panel panel-<?= ($update) ? "warning" : "info" ?>">
                <div class="panel-heading"><h3 class="text-center"><?= ($update) ? "EDIT" : "TAMBAH" ?></h3></div>
                <div class="panel-body">
                    <form action="<?= ($update) ? base_url('admin/mobil/'.$mobilDetail["id"].'/update') : base_url('admin/mobil/create') ?>" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="id_jenis">Jenis</label>
                            <select class="form-control" name="id_jenis">
                                <option>---</option>
                                <?php foreach ($jenis as $j): ?>
                                    <option value="<?=$j["id"]?>" <?= (!$update) ?: (($j["id"] != $j["id"]) ?: 'selected="on"') ?>><?=$j["nama"]?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="no_mobil">No Mobil</label>
                            <input type="text" name="no_mobil" class="form-control" <?= ($update) ? 'value="'.$mobilDetail["no_mobil"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="nama_mobil">Nama Mobil</label>
                            <input type="text" name="nama_mobil" class="form-control" <?= ($update) ? 'value="'.$mobilDetail["nama_mobil"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="merk">Merk</label>
                            <input type="text" name="merk" class="form-control" <?= ($update) ? 'value="'.$mobilDetail["merk"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="gambar">Gambar</label>
                            <input type="file" name="gambar" class="form-control">
                            <?php if ($update): ?>
                                <span class="help-block">*) Kosongkang jika tidak diubah</span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="harga">Harga Sewa</label>
                            <input type="text" name="harga" class="form-control" <?= ($update) ? 'value="'.$mobilDetail["harga"].'"' : '' ?>>
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select class="form-control" name="status">
                                <option>---</option>
                                <option value="0" <?= (!$update) ?: (($mobilDetail["status"] != 0) ?: 'selected="on"') ?>>Tidak Tersedia</option>
                                <option value="1" <?= (!$update) ?: (($mobilDetail["status"] != 1) ?: 'selected="on"') ?>>Tersedia</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-<?= ($update) ? "warning" : "info" ?> btn-block">Simpan</button>
                        <?php if ($update): ?>
                            <a href="<?= base_url('admin/mobil') ?>" class="btn btn-info btn-block">Batal</a>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="panel panel-info">
                <div class="panel-heading"><h3 class="text-center">DAFTAR MOBIL</h3></div>
                <div class="panel-body">
                    <table class="table table-condensed">
                        <thead>
                        <tr>
                            <th>No</th>
                            <th>Jenis</th>
                            <th>No Mobil</th>
                            <th>Nama</th>
                            <th>Merk</th>
                            <th>Harga</th>
                            <th>Status</th>
                            <th class="hidden-print"></th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $no = 1; ?>
                        <?php foreach ($mobil as $m) : ?>
                                <tr>
                                    <td><?=$no++?></td>
                                    <td><?=$m['nama_mobil']?></td>
                                    <td><?=$m['no_mobil']?></td>
                                    <td><?=$m['nama_mobil']?></td>
                                    <td><?=$m['merk']?></td>
                                    <td><?=number_format($m['harga'], '0', ',', '.')?></td>
                                    <td><span class="label label-<?=($m['status']) ? "success" : "danger" ?>"><?=($m['status']) ? "Tersedia" : "Tidak Tersedia" ?></span></td>
                                    <td class="hidden-print">
                                        <div class="btn-group">
                                            <a href="<?=base_url('assets/img/mobil/') . $m['gambar']?>" class="btn btn-info btn-xs fancybox">Lihat</a>
                                            <a href="<?= base_url('admin/mobil/'.$m['id'].'/edit') ?>" class="btn btn-warning btn-xs">Edit</a>
                                            <a href="<?= base_url('admin/mobil/'.$m['id'].'/destroy') ?>" class="btn btn-danger btn-xs">Hapus</a>
                                        </div>
                                    </td>
                                </tr>
                        <?php endforeach ?>
                        </tbody>
                    </table>
                </div>
                <div class="panel-footer hidden-print">
                    <a onClick="window.print();return false" class="btn btn-primary"><i class="glyphicon glyphicon-print"></i></a>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        $(document).ready(function(){
            $(".fancybox").fancybox({
                openEffect  : 'none',
                closeEffect : 'none',
                iframe : {
                    preload: false
                }
            });
            $(".various").fancybox({
                maxWidth    : 800,
                maxHeight    : 600,
                fitToView    : false,
                width        : '70%',
                height        : '70%',
                autoSize    : false,
                closeClick    : false,
                openEffect    : 'none',
                closeEffect    : 'none'
            });
            $('.fancybox-media').fancybox({
                openEffect  : 'none',
                closeEffect : 'none',
                helpers : {
                    media : {}
                }
            });
        });
    </script>

<?= $this->endSection() ?>
