<?= $this->extend('layout/admin') ?>

<?= $this->section('content') ?>

    <form class="form-inline hidden-print" action="<?= base_url('admin/laporan/permobil') ?>" method="post">
        <label>Mobil :</label>
        <select class="form-control" name="id_mobil">
            <option>---</option>
            <?php foreach ($mobil as $m): ?>
                <option value="<?=$m["id"]?>"><?=$m["nama_mobil"]?> | <?=$m["no_mobil"]?></option>
            <?php endforeach; ?>
        </select>
        <label>Tgl :</label>
        <input type="date" class="form-control" name="start">
        <label>s/d</label>
        <input type="date" class="form-control" name="stop">
        <button type="submit" class="btn btn-primary">Tampilkan</button>
    </form>
    <br>
    <?php if (isset($permobil)): ?>
        <div class="panel panel-info">
            <div class="panel-heading"><h3 class="text-center">LAPORAN PENYEWAAN PERMOBIL</h3><br><h4 class="text-center">tgl: <?=$start." s/d ".$stop?></h4></div>
            <div class="panel-body">
                <?php foreach ($permobil as $pm): ?>
                    <form class="form-inline">
                        <table>
                            <tr>
                                <td>
                                    <label>Nomor Mobil</label>
                                </td>
                                <td>&nbsp;:&nbsp;
                                    <input type="text" value="<?=$pm['no_mobil']?>" class="form-control" disabled="on"><br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Nama Mobil</label>
                                </td>
                                <td>&nbsp;:&nbsp;
                                    <input type="text" value="<?=$pm['nama_mobil']?>" class="form-control" disabled="on"><br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Merk</label>
                                </td>
                                <td>&nbsp;:&nbsp;
                                    <input type="text" value="<?=$pm['merk']?>" class="form-control" disabled="on">
                                </td>
                            </tr>
                        </table>
                    </form>
                <?php endforeach; ?>
                <br>
                <table class="table table-condensed">
                    <thead>
                    <tr>
                        <th>No</th>
                        <th>Pelanggan</th>
                        <th>Harga Sewa</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $no = 1; ?>
                    <?php foreach ($permobil as $pm): ?>
                        <tr>
                            <td><?=$no++?></td>
                            <td><?=$pm['nama']?></td>
                            <td>Rp.<?=number_format($pm['harga'], '0', ',', '.')?></td>

                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer hidden-print">
                <a onClick="window.print();return false" class="btn btn-primary"><i class="glyphicon glyphicon-print"></i></a>
            </div>
        </div>
    <?php endif; ?>

<?= $this->endSection() ?>
