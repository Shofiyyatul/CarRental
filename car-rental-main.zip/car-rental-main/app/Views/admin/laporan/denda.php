<?= $this->extend('layout/admin') ?>

<?= $this->section('content') ?>

    <form class="form-inline hidden-print" action="<?= base_url('admin/laporan/denda') ?>" method="post">
        <label>Periode</label>
        <input type="date" class="form-control" name="start">
        <label>s/d</label>
        <input type="date" class="form-control" name="stop">
        <button type="submit" class="btn btn-primary btn-sm">Tampilkan</button>
    </form>
    <br>
    <?php if (isset($denda)): ?>
        <div class="panel panel-info">
            <div class="panel-heading"><h3 class="text-center">LAPORAN DENDA</h3><h4 class="text-center">tgl: <?=$start?> s/d <?=$stop?></h4></div>
            <div class="panel-body">
                <table class="table table-condensed">
                    <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Pelanggan</th>
                        <th>Tanggal Ambil</th>
                        <th>Tanggal Kembali</th>
                        <th>Terlambat</th>
                        <th>Total Harga</th>
                        <th>Denda</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $no = 1; ?>
                    <?php foreach ($denda as $d): ?>
                        <tr>
                            <td><?=$no++?></td>
                            <td><?=$d['nama']?></td>
                            <td><?=date("d-m-Y H:i:s", strtotime($d['tgl_ambil']))?></td>
                            <td><?=date("d-m-Y H:i:s", strtotime($d['tgl_kembali']))?></td>
                            <td><?=$d['terlambat']?> jam</td>
                            <td>Rp.<?=number_format($d['total_harga'], '0', ',', '.')?>,-</td>
                            <td>Rp.<?=number_format($d['denda'], '0', ',', '.')?>,-</td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer hidden-print">
                <a onClick="window.print();return false" class="btn btn-primary"><i class="glyphicon glyphicon-print"></i></a>
            </div>
        </div>
    <?php endif; ?>

<?= $this->endSection() ?>
