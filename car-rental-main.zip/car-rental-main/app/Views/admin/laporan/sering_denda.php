<?= $this->extend('layout/admin') ?>

<?= $this->section('content') ?>

    <form class="form-inline hidden-print" action="<?=base_url('admin/laporan/sering_denda')?>" method="post">
        <label>Periode</label>
        <input type="date" class="form-control" name="start">
        <label>s/d</label>
        <input type="date" class="form-control" name="stop">
        <button type="submit" class="btn btn-primary btn-sm">Tampilkan</button>
    </form>
    <br>
    <?php if (isset($seringDenda)): ?>
        <div class="panel panel-info">
            <div class="panel-heading"><h3 class="text-center">LAPORAN PELANGGAN DENDA TERBANYAK PERPERIODE</h3></div>
            <div class="panel-body">
                <table class="table table-condensed">
                    <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Jumlah</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $no = 1; ?>
                    <?php foreach ($seringDenda as $sd): ?>
                        <tr>
                            <td><?=$no++?></td>
                            <td><?=$sd['nama']?></td>
                            <td><?=$sd['jumlah']?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="panel-footer hidden-print">
                <a onClick="window.print();return false" class="btn btn-primary"><i class="glyphicon glyphicon-print"></i></a>
            </div>
        </div>
    <?php endif; ?>

<?= $this->endSection() ?>
