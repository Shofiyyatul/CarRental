<?= $this->extend('layout/admin') ?>

<?= $this->section('content') ?>



<?= $this->endSection() ?>