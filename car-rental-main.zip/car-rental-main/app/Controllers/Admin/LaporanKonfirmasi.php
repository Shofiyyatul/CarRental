<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\TransaksiModel;

class LaporanKonfirmasi extends BaseController
{
    public function index()
    {
        return view('admin/laporan/konfirmasi');
    }

    public function get()
    {
        $transaksiModel = new TransaksiModel();
        $start = $this->request->getVar('start');
        $stop  = $this->request->getVar('stop');

        $data['konfirmasi'] = $transaksiModel->getKonfirmasi($start, $stop)->getResultArray();

        return view('admin/laporan/konfirmasi', $data);
    }
}