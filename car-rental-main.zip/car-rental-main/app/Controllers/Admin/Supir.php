<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\SupirModel;

class Supir extends BaseController
{
    public function index()
    {
        $supirModel = new SupirModel();
        $data['supir'] = $supirModel->findAll();
        $data['update'] = false;

        return view('admin/supir', $data);
    }

    public function create()
    {
        $supirModel = new SupirModel();
        $payload = [
            'nama'   => $this->request->getVar('nama'),
            'telp'   => $this->request->getVar('telp'),
            'alamat' => $this->request->getVar('alamat'),
            'status' => $this->request->getVar('status'),
        ];
        $supirModel->insert($payload);

        return redirect()->to(base_url('admin/supir'));
    }

    public function edit($id)
    {
        $supirModel = new SupirModel();
        $data['update'] = true;
        $data['supir'] = $supirModel->findAll();
        $data['supirDetail'] = $supirModel->find($id);

        return view('admin/supir', $data);
    }

    public function update($id)
    {
        $supirModel = new SupirModel();
        $payload = [
            'nama'   => $this->request->getVar('nama'),
            'telp'   => $this->request->getVar('telp'),
            'alamat' => $this->request->getVar('alamat'),
            'status' => $this->request->getVar('status'),
        ];

        $supirModel->update($id, $payload);
        return redirect()->to(base_url('admin/supir'));
    }

    public function destroy($id)
    {
        $supirModel = new SupirModel();
        $supirModel->delete($id);

        return redirect()->to(base_url('admin/supir'));
    }
}