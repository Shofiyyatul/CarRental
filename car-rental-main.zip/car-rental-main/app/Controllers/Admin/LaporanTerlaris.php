<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\TransaksiModel;

class LaporanTerlaris extends BaseController
{
    public function index()
    {
        return view('admin/laporan/terlaris');
    }

    public function getTerlaris()
    {
        $transaksiModel = new TransaksiModel();

        $data['start'] = $this->request->getVar('start');
        $data['stop']  = $this->request->getVar('stop');
        $data['terlaris']  = $transaksiModel->getTerlaris($data['start'], $data['stop'])->getResultArray();

        return view('admin/laporan/terlaris', $data);
    }
}