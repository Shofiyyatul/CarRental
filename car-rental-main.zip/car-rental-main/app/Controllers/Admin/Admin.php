<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\AdminModel;

class Admin extends BaseController
{
    public function index()
    {
        $adminModel = new AdminModel();
        $data['admin'] = $adminModel->findAll();
        $data['update'] = false;

        return view('admin/admin', $data);
    }

    public function create()
    {
        $adminModel = new AdminModel();
        $payload = [
            'nama'     => $this->request->getVar('nama'),
            'telp'   => $this->request->getVar('telp'),
            'email'  => $this->request->getVar('email'),
            'alamat'   => $this->request->getVar('alamat'),
            'username'    => $this->request->getVar('username'),
            'password' => $this->request->getVar('password'),
            //'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT)
        ];
        $adminModel->insert($payload);

        return redirect()->to(base_url('admin/admin'));
    }

    public function edit($id)
    {
        $adminModel = new AdminModel();
        $data['update'] = true;
        $data['admin'] = $adminModel->findAll();
        $data['adminDetail'] = $adminModel->find($id);

        return view('admin/admin', $data);
    }

    public function update($id)
    {
        $adminModel = new AdminModel();
        $password = $this->request->getVar('password');

        $payload = [
            'nama'     => $this->request->getVar('nama'),
            'telp'   => $this->request->getVar('telp'),
            'email'  => $this->request->getVar('email'),
            'alamat'   => $this->request->getVar('alamat'),
            'username'    => $this->request->getVar('username'),
        ];

        if (!$password != "") {
            //$payload['password'] = password_hash($this->request->getVar('password'), PASSWORD_DEFAULT)
            $payload['password'] = $this->request->getVar('password');
        }

        $adminModel->update($id, $payload);
        return redirect()->to(base_url('admin/admin'));
    }

    public function destroy($id)
    {
        $adminModel = new AdminModel();
        $adminModel->delete($id);

        return redirect()->to(base_url('admin/admin'));
    }
}