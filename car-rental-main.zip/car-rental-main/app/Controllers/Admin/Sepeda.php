<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\SepedaModel;

class Sepeda extends BaseController
{
    public function index()
    {
        $sepedaModel = new SepedaModel();
        $data['sepeda'] = $sepedaModel->findAll();
        $data['update'] = false;

        return view('admin/sepeda', $data);
    }

    public function create()
    {
        $sepedaModel = new SepedaModel();
        $payload = [
            'nama'    => $this->request->getVar('nama'),
            'merk'    => $this->request->getVar('merk'),
            'no_seri' => $this->request->getVar('no_seri'),
            'gambar'  => $this->request->getVar('gambar'),
            'harga'   => $this->request->getVar('harga'),
            'status'  => $this->request->getVar('status'),
        ];
        $sepedaModel->insert($payload);

        return redirect()->to(base_url('admin/sepeda'));
    }

    public function edit($id)
    {
        $sepedaModel = new SepedaModel();
        $data['update'] = true;
        $data['sepeda'] = $sepedaModel->findAll();
        $data['sepedaDetail'] = $sepedaModel->find($id);

        return view('admin/sepeda', $data);
    }

    public function update($id)
    {
        $sepedaModel = new SepedaModel();
        $gambar = $this->request->getVar('gambar');
        $payload = [
            'nama'    => $this->request->getVar('nama'),
            'merk'    => $this->request->getVar('merk'),
            'no_seri' => $this->request->getVar('no_seri'),
            'gambar'  => $this->request->getVar('gambar'),
            'harga'   => $this->request->getVar('harga'),
            'status'  => $this->request->getVar('status'),
        ];

        if (!$gambar != "") {
            $payload['gambar'] = $this->request->getVar('gambar');
        }

        $sepedaModel->update($id, $payload);
        return redirect()->to(base_url('admin/sepeda'));
    }

    public function destroy($id)
    {
        $sepedaModel = new SepedaModel();
        $sepedaModel->delete($id);

        return redirect()->to(base_url('admin/sepeda'));
    }
}