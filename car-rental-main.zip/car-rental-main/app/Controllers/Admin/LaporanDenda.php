<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\TransaksiModel;

class LaporanDenda extends BaseController
{
    public function index()
    {
        return view('admin/laporan/denda');
    }

    public function getDenda()
    {
        $transaksiModel = new TransaksiModel();

        $data['start'] = $this->request->getVar('start');
        $data['stop']  = $this->request->getVar('stop');
        $data['denda']  = $transaksiModel->getDenda($data['start'], $data['stop'])->getResultArray();

        return view('admin/laporan/denda', $data);
    }
}