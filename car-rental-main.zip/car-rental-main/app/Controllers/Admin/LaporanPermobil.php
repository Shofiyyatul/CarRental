<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\MobilModel;
use App\Models\TransaksiModel;

class LaporanPermobil extends BaseController
{
    public function index()
    {
        $mobilModel    = new MobilModel();
        $data['mobil'] = $mobilModel->findAll();

        return view('admin/laporan/permobil', $data);
    }

    public function getPenyewaanPermobil()
    {
        $transaksiModel = new TransaksiModel();
        $mobilModel     = new MobilModel();

        $data['start'] = $this->request->getVar('start');
        $data['stop']  = $this->request->getVar('stop');

        $data['mobil']     = $mobilModel->findAll();
        $data['permobil']  = $transaksiModel->getPenyewaanPermobil($data['start'], $data['stop'])->getResultArray();

        return view('admin/laporan/permobil', $data);
    }
}