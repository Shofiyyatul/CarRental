<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\AdminModel;

class Auth extends BaseController
{
    public function login()
    {
        helper(['form']);
        $data = [];
        return view('admin/login', $data);
    }

    public function loginAction()
    {
        $adminModel = new AdminModel();
        $username = $this->request->getVar('username');
        $password = $this->request->getVar('password');

        $data = $adminModel->where('username', 'admin')->first();

        if ($data) {
            $pass = $data['password'];
            if(password_verify($password, $pass)) {
                session()->set([
                    'is_logged' => TRUE,
                    'is_admin'  => TRUE,
                    'id'        => $data['id'],
                    'nama'      => $data['nama'],
                    'username'  => $data['username']
                ]);
                return redirect()->to(base_url('admin'));
            }else{
                session()->setFlashdata('error', 'Password tidak sesuai.');
                return redirect()->to(base_url('admin'));
            }
        } else {
            session()->setFlashdata('error', 'Username tidak ditemukan.');
            return redirect()->to(base_url('admin'));
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('admin/login'));
    }
}