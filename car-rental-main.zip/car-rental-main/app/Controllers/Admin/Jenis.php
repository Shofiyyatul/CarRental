<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\JenisModel;

class Jenis extends BaseController
{
    public function index()
    {
        $jenisModel = new JenisModel();
        $data['jenis'] = $jenisModel->findAll();
        $data['update'] = false;

        return view('admin/jenis', $data);
    }

    public function create()
    {
        $jenisModel = new JenisModel();
        $payload = [
            'nama_jenis'     => $this->request->getVar('nama'),
        ];
        $jenisModel->insert($payload);

        return redirect()->to(base_url('admin/jenis'));
    }

    public function edit($id)
    {
        $jenisModel = new JenisModel();
        $data['update'] = true;
        $data['jenis'] = $jenisModel->findAll();
        $data['jenisDetail'] = $jenisModel->find($id);

        return view('admin/jenis', $data);
    }

    public function update($id)
    {
        $jenisModel = new JenisModel();
        $payload = [
            'nama_jenis'     => $this->request->getVar('nama'),
        ];

        $jenisModel->update($id, $payload);
        return redirect()->to(base_url('admin/jenis'));
    }

    public function destroy($id)
    {
        $jenisModel = new JenisModel();
        $jenisModel->delete($id);

        return redirect()->to(base_url('admin/jenis'));
    }
}