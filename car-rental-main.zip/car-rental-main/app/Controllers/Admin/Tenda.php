<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\TendaModel;

class Tenda extends BaseController
{
    public function index()
    {
        $tendaModel = new TendaModel();
        $data['tenda'] = $tendaModel->findAll();
        $data['update'] = false;

        return view('admin/tenda', $data);
    }

    public function create()
    {
        $tendaModel = new TendaModel();
        $payload = [
            'nama'    => $this->request->getVar('nama'),
            'merk'    => $this->request->getVar('merk'),
            'no_seri' => $this->request->getVar('no_seri'),
            'gambar'  => $this->request->getVar('gambar'),
            'harga'   => $this->request->getVar('harga'),
            'status'  => $this->request->getVar('status'),
        ];
        $tendaModel->insert($payload);

        return redirect()->to(base_url('admin/tenda'));
    }

    public function edit($id)
    {
        $tendaModel = new TendaModel();
        $data['update'] = true;
        $data['tenda'] = $tendaModel->findAll();
        $data['tendaDetail'] = $tendaModel->find($id);

        return view('admin/tenda', $data);
    }

    public function update($id)
    {
        $tendaModel = new TendaModel();
        $gambar = $this->request->getVar('gambar');
        $payload = [
            'nama'    => $this->request->getVar('nama'),
            'merk'    => $this->request->getVar('merk'),
            'no_seri' => $this->request->getVar('no_seri'),
            'gambar'  => $this->request->getVar('gambar'),
            'harga'   => $this->request->getVar('harga'),
            'status'  => $this->request->getVar('status'),
        ];

        if (!$gambar != "") {
            $payload['gambar'] = $this->request->getVar('gambar');
        }

        $tendaModel->update($id, $payload);
        return redirect()->to(base_url('admin/tenda'));
    }

    public function destroy($id)
    {
        $tendaModel = new TendaModel();
        $tendaModel->delete($id);

        return redirect()->to(base_url('admin/tenda'));
    }
}