<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\PelangganModel;

class Pelanggan extends BaseController
{
    public function index()
    {
        $pelangganModel = new PelangganModel();
        $data['pelanggan'] = $pelangganModel->findAll();
        $data['update'] = false;

        return view('admin/pelanggan', $data);
    }

    public function create()
    {
        $pelangganModel = new PelangganModel();
        $payload = [
            'no_ktp'   => $this->request->getVar('no_ktp'),
            'nama'     => $this->request->getVar('nama'),
            'email'    => $this->request->getVar('email'),
            'no_telp'  => $this->request->getVar('no_telp'),
            'alamat'   => $this->request->getVar('alamat'),
            'username' => $this->request->getVar('username'),
            'password' => $this->request->getVar('password'),
        ];
        $pelangganModel->insert($payload);

        return redirect()->to(base_url('admin/pelanggan'));
    }

    public function edit($id)
    {
        $pelangganModel = new PelangganModel();
        $data['update'] = true;
        $data['pelanggan'] = $pelangganModel->findAll();
        $data['pelangganDetail'] = $pelangganModel->find($id);

        return view('admin/pelanggan', $data);
    }

    public function update($id)
    {
        $pelangganModel = new PelangganModel();
        $password = $this->request->getVar('password');

        $payload = [
            'no_ktp'     => $this->request->getVar('no_ktp'),
            'nama'     => $this->request->getVar('nama'),
            'email'     => $this->request->getVar('email'),
            'no_telp'     => $this->request->getVar('no_telp'),
            'alamat'     => $this->request->getVar('alamat'),
            'username'     => $this->request->getVar('username')
        ];

        if (!$password != "") {
            //$payload['password'] = password_hash($this->request->getVar('password'), PASSWORD_DEFAULT)
            $payload['password'] = $this->request->getVar('password');
        }

        $pelangganModel->update($id, $payload);
        return redirect()->to(base_url('admin/pelanggan'));
    }

    public function destroy($id)
    {
        $pelangganModel = new PelangganModel();
        $pelangganModel->delete($id);

        return redirect()->to(base_url('admin/pelanggan'));
    }
}