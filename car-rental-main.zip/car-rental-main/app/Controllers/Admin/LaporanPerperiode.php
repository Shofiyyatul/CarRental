<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\TransaksiModel;

class LaporanPerperiode extends BaseController
{
    public function index()
    {
        return view('admin/laporan/perperiode');
    }

    public function getPerperiode()
    {
        $transaksiModel = new TransaksiModel();

        $data['start'] = $this->request->getVar('start');
        $data['stop']  = $this->request->getVar('stop');
        $data['perperiode']  = $transaksiModel->getPerperiode($data['start'], $data['stop'])->getResultArray();

        return view('admin/laporan/perperiode', $data);
    }
}