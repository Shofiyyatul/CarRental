<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\JenisModel;
use App\Models\MobilModel;

class Mobil extends BaseController
{
    public function index()
    {
        $mobilModel = new MobilModel();
        $jenisModel = new JenisModel();
        $data['mobil'] = $mobilModel->findAll();
        $data['update'] = false;
        $data['jenis'] = $jenisModel->findAll();

        return view('admin/mobil', $data);
    }

    public function create()
    {
        $mobilModel = new MobilModel();
        $payload = [
            'id_jenis'   => $this->request->getVar('id_jenis'),
            'no_mobil'   => $this->request->getVar('no_mobil'),
            'merk'       => $this->request->getVar('merk'),
            'nama_mobil' => $this->request->getVar('nama_mobil'),
            'gambar'     => $this->request->getVar('gambar'),
            'harga'      => $this->request->getVar('harga'),
            'status'     => $this->request->getVar('status'),
        ];
        $mobilModel->insert($payload);

        return redirect()->to(base_url('admin/mobil'));
    }

    public function edit($id)
    {
        $mobilModel = new MobilModel();
        $data['update'] = true;
        $data['mobil'] = $mobilModel->findAll();
        $data['mobilDetail'] = $mobilModel->find($id);

        return view('admin/mobil', $data);
    }

    public function update($id)
    {
        $mobilModel = new MobilModel();
        $gambar = $this->request->getVar('gambar');
        $payload = [
            'id_jenis'   => $this->request->getVar('id_jenis'),
            'no_mobil'   => $this->request->getVar('no_mobil'),
            'merk'       => $this->request->getVar('merk'),
            'nama_mobil' => $this->request->getVar('nama_mobil'),
            'harga'      => $this->request->getVar('harga'),
            'status'     => $this->request->getVar('status'),
        ];

        if (!$gambar != "") {
            $payload['gambar'] = $this->request->getVar('gambar');
        }

        $mobilModel->update($id, $payload);
        return redirect()->to(base_url('admin/mobil'));
    }

    public function destroy($id)
    {
        $mobilModel = new MobilModel();
        $mobilModel->delete($id);

        return redirect()->to(base_url('admin/mobil'));
    }
}