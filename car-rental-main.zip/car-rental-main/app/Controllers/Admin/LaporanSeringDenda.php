<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\TransaksiModel;

class LaporanSeringDenda extends BaseController
{
    public function index()
    {
        return view('admin/laporan/sering_denda');
    }

    public function getSeringDenda()
    {
        $transaksiModel = new TransaksiModel();

        $data['start'] = $this->request->getVar('start');
        $data['stop']  = $this->request->getVar('stop');
        $data['seringDenda']  = $transaksiModel->getSeringDenda($data['start'], $data['stop'])->getResultArray();

        return view('admin/laporan/sering_denda', $data);
    }
}