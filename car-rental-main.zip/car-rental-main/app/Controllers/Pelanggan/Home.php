<?php

namespace App\Controllers\Pelanggan;

use App\Controllers\BaseController;
use App\Models\MobilModel;

class Home extends BaseController
{
    public function index()
    {
        $mobilModel = new MobilModel();
        $data['mobil'] = $mobilModel->findAll();

        return view('pelanggan/home', $data);
    }
}
