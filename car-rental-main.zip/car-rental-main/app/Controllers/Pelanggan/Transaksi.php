<?php

namespace App\Controllers\Pelanggan;

use App\Controllers\BaseController;
use App\Models\MobilModel;
use App\Models\SupirModel;
use App\Models\TransaksiModel;

class Transaksi extends BaseController
{
    public function sewaMobilIndex($id)
    {
        $supirModel = new SupirModel();

        $data['id']    = $id;
        $data['supir'] = $supirModel->cekSupir();

        return view('pelanggan/transaksi', $data);
    }

    public function createSewaMobil($id)
    {
        $transaksiModel = new TransaksiModel();
        $mobilModel     = new MobilModel();

        $lama        = $this->request->getVar('lama');
        $idMobil     = $this->request->getVar('id_mobil');
        $hargaSewa   = $mobilModel->find($idMobil)['harga'];
        $hargaSupir  = 30000;
        $total_harga = $lama * ($hargaSewa + $hargaSupir);

        $payloadTransaksi = [
            'id_pelanggan' => session()->get('id'),
            'id_mobil'     => $idMobil,
            'tgl_sewa'     => date('Y-m-d H:i:s'),
            'tgl_ambil'    => $this->request->getVar('tgl_ambil'),
            'jaminan'      => $this->request->getVar('jaminan'),
            'lama'         => $this->request->getVar('lama'),
            'total_harga'  => $total_harga,
            'jatuh_tempo'  => date('Y-m-d H:i:s', strtotime('+3 hours')),
            'status'       => '0',
            'konfirmasi'   => '0',
            'pembatalan'   => '0',
        ];

        $transaksiModel->insert($payloadTransaksi);
        $mobilModel->update($idMobil, ['status' => '0']);

        $data['transaksi'] =  $payloadTransaksi;
        $data['harga'] =  [
            'harga_sewa' => $hargaSewa,
            'harga_supir' => $hargaSupir
        ];

        return view('pelanggan/selesai', $data);
    }

    public function detailTransaksi($id)
    {
        $transaksiModel = new TransaksiModel();
        $data['transaksi'] = $transaksiModel->getDetailTransaksi($id)->getFirstRow();

        return view('pelanggan/detail', $data);
    }

    public function konfirmasiTransaksiIndex($id)
    {
        $data['id'] = $id;

        return view('pelanggan/konfirmasi', $data);
    }

    public function uploadBuktiKonfirmasi($id)
    {
        $bukti = $this->request->getVar('bukti');

        return redirect()->to(base_url('profil'));
    }
}