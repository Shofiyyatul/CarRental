<?php

namespace App\Controllers\Pelanggan;

use App\Controllers\BaseController;
use App\Models\PelangganModel;
use App\Models\TransaksiModel;

class Profil extends BaseController
{
    public function index()
    {
        $transaksiModel = new TransaksiModel();
        $pelangganModel = new PelangganModel();
        $id_pelanggan = session()->get('id');

        $data['pelanggan'] = $pelangganModel->find($id_pelanggan);
        $data['transaksi'] = $transaksiModel->getRiwayatTransaksi($id_pelanggan)->getResultArray();
        $data['denda']     = $transaksiModel->getRiwayatDenda($id_pelanggan)->getResultArray();

        return view('pelanggan/profil', $data);
    }
}