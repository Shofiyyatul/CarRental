<?php

namespace App\Controllers\Pelanggan;

use App\Controllers\BaseController;
use App\Models\PelangganModel;

class Auth extends BaseController
{
    public function login()
    {
        helper(['form']);
        $data = [];
        return view('pelanggan/login', $data);
    }

    public function daftar()
    {
        helper(['form']);
        $data = [];
        return view('pelanggan/daftar', $data);
    }

    public function loginAction()
    {
        $pelanggannModel = new PelangganModel();
        $username        = $this->request->getVar('username');
        $password        = $this->request->getVar('password');

        $data = $pelanggannModel->where('username', $username)->first();

        if($data){
            $pass = $data['password'];
            if(password_verify($password, $pass)) {
                session()->set([
                    'is_logged' => TRUE,
                    'is_admin'  => FALSE,
                    'id'        => $data['id'],
                    'nama'      => $data['nama'],
                    'email'     => $data['email'],
                    'username'  => $data['username']
                ]);
                return redirect()->to(base_url(''));
            }else{
                session()->setFlashdata('error', 'Password tidak sesuai.');
                return redirect()->to(base_url('login'));
            }
        }else{
            session()->setFlashdata('error', 'Username tidak ditemukan.');
            return redirect()->to(base_url('login'));
        }
    }

    public function registerAction()
    {
        $pelangganModel = new PelangganModel();
        $data = [
            'nama'     => $this->request->getVar('nama'),
            'no_ktp'   => $this->request->getVar('no_ktp'),
            'no_telp'  => $this->request->getVar('no_telp'),
            'alamat'   => $this->request->getVar('alamat'),
            'email'    => $this->request->getVar('email'),
            'username' => $this->request->getVar('username'),
            'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT)
        ];
        $pelangganModel->insert($data);

        session()->setFlashdata('success', 'Daftar berhasil! Silahkan Login');
        return redirect()->to(base_url('login'));
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('login'));
    }
}