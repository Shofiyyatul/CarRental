<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
//$routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.

/**
 * ------------------------------------------------------------------
 * Customer Route Section.
 * ------------------------------------------------------------------
 */
$routes->get('/', 'Pelanggan\Home::index');

$routes->group('login', static function($routes) {
    $routes->get('/', 'Pelanggan\Auth::login');
    $routes->post('post', 'Pelanggan\Auth::loginAction');
});

$routes->group('daftar', static function($routes) {
    $routes->get('/', 'Pelanggan\Auth::daftar');
    $routes->post('post', 'Pelanggan\Auth::registerAction');
});

$routes->get('profil', 'Pelanggan\profil::index', ['filter' => 'usersAuth:dual,noreturn']);

$routes->group('transaksi', static function($routes) {
    $routes->get('(:segment)/sewa', 'Pelanggan\Transaksi::sewaMobilIndex/$1', ['filter' => 'usersAuth:dual,noreturn']);
    $routes->post('(:segment)/sewa', 'Pelanggan\Transaksi::createSewaMobil/$1', ['filter' => 'usersAuth:dual,noreturn']);
    $routes->get('(:segment)/detail', 'Pelanggan\Transaksi::detailTransaksi/$1', ['filter' => 'usersAuth:dual,noreturn']);
    $routes->get('(:segment)/konfirmasi', 'Pelanggan\Transaksi::konfirmasiTransaksiIndex/$1', ['filter' => 'usersAuth:dual,noreturn']);
    $routes->post('(:segment)/konfirmasi', 'Pelanggan\Transaksi::uploadBuktiKonfirmasi/$1', ['filter' => 'usersAuth:dual,noreturn']);
});

$routes->get('logout', 'Pelanggan\Auth::logout', ['filter' => 'usersAuth:dual,noreturn']);


/**
 * ------------------------------------------------------------------
 * Admin Route Section.
 * ------------------------------------------------------------------
 */
$routes->group('admin', static function ($routes) {

    $routes->get('/', 'Admin\Home::index', ['filter' => 'adminAuth:dual,noreturn']);

    $routes->group('login', static function($routes) {
        $routes->get('/', 'Admin\Auth::login');
        $routes->post('', 'Admin\Auth::loginAction');
    });

    $routes->get('logout', 'Admin\Auth::logout', ['filter' => 'adminAuth:dual,noreturn']);

    $routes->group('admin', static function($routes) {
        $routes->get('/', 'Admin\Admin::index', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->post('create', 'Admin\Admin::create', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/edit', 'Admin\Admin::edit/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/update', 'Admin\Admin::update/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->get('(:segment)/destroy', 'Admin\Admin::destroy/$1', ['filter' => 'adminAuth:dual,noreturn']);
    });

    $routes->group('jenis', static function($routes) {
        $routes->get('/', 'Admin\Jenis::index', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->post('create', 'Admin\Jenis::create', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/edit', 'Admin\Jenis::edit/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/update', 'Admin\Jenis::update/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->get('(:segment)/destroy', 'Admin\Jenis::destroy/$1', ['filter' => 'adminAuth:dual,noreturn']);
    });

    $routes->group('tenda', static function($routes) {
        $routes->get('/', 'Admin\Tenda::index', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->post('create', 'Admin\Tenda::create', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/edit', 'Admin\Tenda::edit/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/update', 'Admin\Tenda::update/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->get('(:segment)/destroy', 'Admin\Tenda::destroy/$1', ['filter' => 'adminAuth:dual,noreturn']);
    });

    $routes->group('sepeda', static function($routes) {
        $routes->get('/', 'Admin\Sepeda::index', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->post('create', 'Admin\Sepeda::create', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/edit', 'Admin\Sepeda::edit/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/update', 'Admin\Sepeda::update/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->get('(:segment)/destroy', 'Admin\Sepeda::destroy/$1', ['filter' => 'adminAuth:dual,noreturn']);
    });

    $routes->group('mobil', static function($routes) {
        $routes->get('/', 'Admin\Mobil::index', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->post('create', 'Admin\Mobil::create', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/edit', 'Admin\Mobil::edit/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/update', 'Admin\Mobil::update/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->get('(:segment)/destroy', 'Admin\Mobil::destroy/$1', ['filter' => 'adminAuth:dual,noreturn']);
    });

    $routes->group('supir', static function($routes) {
        $routes->get('/', 'Admin\Supir::index', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->post('create', 'Admin\Supir::create', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/edit', 'Admin\Supir::edit/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/update', 'Admin\Supir::update/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->get('(:segment)/destroy', 'Admin\Supir::destroy/$1', ['filter' => 'adminAuth:dual,noreturn']);
    });

    $routes->group('pelanggan', static function($routes) {
        $routes->get('/', 'Admin\Pelanggan::index', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->post('create', 'Admin\Pelanggan::create', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/edit', 'Admin\Pelanggan::edit/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->add('(:segment)/update', 'Admin\Pelanggan::update/$1', ['filter' => 'adminAuth:dual,noreturn']);
        $routes->get('(:segment)/destroy', 'Admin\Pelanggan::destroy/$1', ['filter' => 'adminAuth:dual,noreturn']);
    });

    $routes->group('laporan', static function($routes) {
        $routes->group('konfirmasi', static function($routes) {
            $routes->get('', 'Admin\LaporanKonfirmasi::index', ['filter' => 'adminAuth:dual,noreturn']);
            $routes->post('', 'Admin\LaporanKonfirmasi::get', ['filter' => 'adminAuth:dual,noreturn']);
        });

        $routes->group('permobil', static function($routes) {
            $routes->get('', 'Admin\LaporanPermobil::index', ['filter' => 'adminAuth:dual,noreturn']);
            $routes->post('', 'Admin\LaporanPermobil::getPenyewaanPermobil', ['filter' => 'adminAuth:dual,noreturn']);
        });

        $routes->group('sering_denda', static function($routes) {
            $routes->get('', 'Admin\LaporanSeringDenda::index', ['filter' => 'adminAuth:dual,noreturn']);
            $routes->post('', 'Admin\LaporanSeringDenda::getSeringDenda', ['filter' => 'adminAuth:dual,noreturn']);
        });

        $routes->group('perperiode', static function($routes) {
            $routes->get('', 'Admin\LaporanPerperiode::index', ['filter' => 'adminAuth:dual,noreturn']);
            $routes->post('', 'Admin\LaporanPerperiode::getPerperiode', ['filter' => 'adminAuth:dual,noreturn']);
        });

        $routes->group('terlaris', static function($routes) {
            $routes->get('', 'Admin\LaporanTerlaris::index', ['filter' => 'adminAuth:dual,noreturn']);
            $routes->post('', 'Admin\LaporanTerlaris::getTerlaris', ['filter' => 'adminAuth:dual,noreturn']);
        });

        $routes->group('denda', static function($routes) {
            $routes->get('', 'Admin\LaporanDenda::index', ['filter' => 'adminAuth:dual,noreturn']);
            $routes->post('', 'Admin\LaporanDenda::getDenda', ['filter' => 'adminAuth:dual,noreturn']);
        });
    });

});

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
