<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class JenisSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'id' => 1,
                'nama_jenis' => 'MPV'
            ],
            [
                'id' => 2,
                'nama_jenis' => 'SUV'
            ],
            [
                'id' => 3,
                'nama_jenis' => 'Sedan'
            ],
            [
                'id' => 4,
                'nama_jenis' => 'City Car'
            ],
            [
                'id' => 5,
                'nama_jenis' => 'Double Cabin'
            ]
        ];

        $this->db->table('jenis')->insertBatch($data);
    }
}
