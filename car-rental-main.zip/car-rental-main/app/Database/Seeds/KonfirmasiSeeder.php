<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class KonfirmasiSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'id' => 1,
                'id_transaksi' => 1,
                'bukti' => '104012020184503.jpg'
            ]
        ];

        $this->db->table('konfirmasi')->insertBatch($data);
    }
}
