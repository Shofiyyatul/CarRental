<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class MobilSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'id' => 1,
                'id_jenis' => 1,
                'no_mobil' => 'F 3134 RI',
                'merk' => 'Toyota',
                'nama_mobil' => 'Avanza',
                'gambar' => '03012020235744.jpg',
                'harga' => '500000',
                'status' => '1',
            ],
            [
                'id' => 2,
                'id_jenis' => 1,
                'no_mobil' => 'F 69 SX',
                'merk' => 'Nissan',
                'nama_mobil' => 'Grand Livina',
                'gambar' => '04012020000026.jpg',
                'harga' => '510000',
                'status' => '0',
            ],
            [
                'id' => 3,
                'id_jenis' => 4,
                'no_mobil' => 'F 1111 IL',
                'merk' => 'Honda',
                'nama_mobil' => 'Jazz',
                'gambar' => '04012020000301.jpg',
                'harga' => '600000',
                'status' => '1',
            ],
            [
                'id' => 4,
                'id_jenis' => 3,
                'no_mobil' => 'F 456 UV',
                'merk' => 'Honda',
                'nama_mobil' => 'Civic',
                'gambar' => '04012020000521.jpg',
                'harga' => '650000',
                'status' => '1',
            ],
            [
                'id' => 5,
                'id_jenis' => 2,
                'no_mobil' => 'F 44 X',
                'merk' => 'Mitsubishi',
                'nama_mobil' => 'Pajero Sport',
                'gambar' => '04012020000701.jpg',
                'harga' => '700000',
                'status' => '1',
            ],
            [
                'id' => 6,
                'id_jenis' => 1,
                'no_mobil' => 'F 9821 YBY',
                'merk' => 'Ford',
                'nama_mobil' => 'Ranger',
                'gambar' => '04012020001126.jpg',
                'harga' => '710000',
                'status' => 1,
            ],
            [
                'id' => 7,
                'id_jenis' => 1,
                'no_mobil' => 'T 35 LA',
                'merk' => 'Tesla',
                'nama_mobil' => 'Model X',
                'gambar' => '04012020001437.jpg',
                'harga' => '780000',
                'status' => 1,
            ],
            [
                'id' => 8,
                'id_jenis' => 1,
                'no_mobil' => 'A 145 ZW',
                'merk' => 'Wuling',
                'nama_mobil' => 'Almaz',
                'gambar' => '04012020001710.jpg',
                'harga' => '680000',
                'status' => 1,
            ]
        ];

        $this->db->table('mobil')->insertBatch($data);
    }
}