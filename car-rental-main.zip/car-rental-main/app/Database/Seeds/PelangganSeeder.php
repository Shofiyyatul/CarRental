<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class PelangganSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'id'       => 1,
                'no_ktp'   => '0038451895665',
                'nama'     => 'Pelanggan Setia',
                'email'    => 'pelanggan@gmail.com',
                'no_telp'  => '089698298584',
                'alamat'   => 'Malang',
                'username' => 'pelanggan',
                'password' => password_hash('password', PASSWORD_DEFAULT),
            ]
        ];

        $this->db->table('pelanggan')->insertBatch($data);
    }
}
