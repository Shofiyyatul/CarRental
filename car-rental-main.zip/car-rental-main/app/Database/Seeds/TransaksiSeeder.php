<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class TransaksiSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'id' => 1,
                'id_pelanggan' => 1,
                'id_mobil' => 3,
                'tgl_sewa' => '2020-01-04 18:44:30',
                'tgl_ambil' => '2020-01-04 18:44:30',
                'tgl_kembali' => null,
                'lama' => 1,
                'total_harga' => 510000,
                'status' => '0',
                'jaminan' => 'Sertifikat Vaksin',
                'denda' => null,
                'jatuh_tempo' => '2020-01-04 21:44:30',
                'konfirmasi' => '1',
                'pembatalan' => '0',

            ]
        ];

        $this->db->table('transaksi')->insertBatch($data);
    }
}
