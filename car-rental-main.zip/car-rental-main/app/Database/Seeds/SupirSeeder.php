<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class SupirSeeder extends Seeder
{
    public function run()
    {
        $data = [
            [
                'id' => 1,
                'nama' => 'Rendi',
                'telp' => '081551155115',
                'alamat' => 'Ngawi',
                'status' => '1'
            ]
        ];

        $this->db->table('supir')->insertBatch($data);
    }
}
