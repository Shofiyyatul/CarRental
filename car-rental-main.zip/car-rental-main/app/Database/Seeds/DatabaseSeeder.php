<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        $this->call('AdminSeeder');
        $this->call('JenisSeeder');
        $this->call('KonfirmasiSeeder');
        $this->call('MobilSeeder');
        $this->call('PelangganSeeder');
        $this->call('SupirSeeder');
        $this->call('TransaksiSeeder');
    }
}