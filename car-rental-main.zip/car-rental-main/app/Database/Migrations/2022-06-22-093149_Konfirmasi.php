<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Konfirmasi extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true
            ],
            'id_transaksi' => [
                'type'           => 'INT',
                'constraint'     => 11
            ],
            'bukti' => [
                'type'           => 'VARCHAR',
                'constraint'     => 100,
                'null'           => false,
            ]
        ]);

        $this->forge->addKey('id', TRUE);
//        $this->forge->addForeignKey('id_transaksi', 'transaksi', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('konfirmasi', TRUE);
//        $this->db->enableForeignKeyChecks();
    }

    public function down()
    {
        $this->forge->dropTable('konfirmasi');
    }
}
