<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Transaksi extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 4,
                'unsigned'       => true,
                'auto_increment' => true
            ],
            'id_pelanggan' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'null'           => false
            ],
            'id_mobil' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'null'           => false
            ],
            'tgl_sewa' => [
                'type'           => 'DATETIME',
                'null'           => false
            ],
            'tgl_ambil' => [
                'type'           => 'DATETIME',
                'null'           => true
            ],
            'tgl_kembali' => [
                'type'           => 'DATETIME',
                'null'           => true
            ],
            'lama' => [
                'type'           => 'TINYINT',
                'constraint'     => 1,
                'null'           => false
            ],
            'total_harga' => [
                'type'           => 'INT',
                'constraint'     => 7,
                'null'           => false
            ],
            'status' => [
                'type'           => 'ENUM',
                'constraint'     => ["0","1"],
                'null'           => false
            ],
            'jaminan' => [
                'type'           => 'VARCHAR',
                'constraint'     => 30,
                'null'           => false
            ],
            'denda' => [
                'type'           => 'INT',
                'constraint'     => 7,
                'null'           => true
            ],
            'jatuh_tempo' => [
                'type'           => 'DATETIME',
            ],
            'konfirmasi' => [
                'type'           => 'ENUM',
                'constraint'     => ["0","1"],
                'null'           => true
            ],
            'pembatalan' => [
                'type'           => 'ENUM',
                'constraint'     => ["0","1"],
                'null'           => true
            ]
        ]);

        $this->forge->addKey('id', TRUE);
//        $this->forge->addForeignKey('id_pelanggan', 'pelanggan', 'id', 'CASCADE', 'CASCADE');
//        $this->forge->addForeignKey('id_mobil', 'mobil', 'id', 'CASCADE', 'NO ACTION');
        $this->forge->createTable('transaksi', TRUE);
//        $this->db->enableForeignKeyChecks();
    }

    public function down()
    {
        $this->forge->dropTable('transaksi');
    }
}
