<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Sepeda extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true
            ],
            'nama' => [
                'type'           => 'VARCHAR',
                'constraint'     => 30,
                'null'           => false,
            ],
            'merk' => [
                'type'           => 'VARCHAR',
                'constraint'     => 20,
                'null'           => false,
            ],
            'no_seri' => [
                'type'           => 'VARCHAR',
                'constraint'     => 20,
                'null'           => false,
            ],
            'gambar' => [
                'type'           => 'VARCHAR',
                'constraint'     => 100,
                'null'           => false,
            ],
            'harga' => [
                'type'           => 'INT',
                'constraint'     => 7,
                'null'           => false,
            ],
            'status' => [
                'type'           => 'ENUM',
                'constraint'     => ["0", "1"],
                'null'           => false,
            ]
        ]);

        $this->forge->addKey('id', TRUE);
        $this->forge->createTable('sepeda', TRUE);
    }

    public function down()
    {
        $this->forge->dropTable('sepeda');
    }
}