<?php

namespace App\Models;

use CodeIgniter\Model;

class SepedaModel extends Model
{
    protected $table = 'sepeda';
    protected $primaryKey = 'id';

    protected $useAutoIncrement = true;
    protected $allowedFields = ['nama', 'merk', 'no_seri', 'gambar', 'harga', 'status'];
}