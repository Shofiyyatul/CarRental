<?php

namespace App\Models;

use CodeIgniter\Model;

class TransaksiModel extends Model
{
    protected $table = 'transaksi';
    protected $primaryKey = 'id';

    protected $useAutoIncrement = true;
    protected $allowedFields = ['id_pelanggan', 'id_mobil', 'tgl_sewa', 'tgl_ambil', 'tgl_kembali', 'lama', 'total_harga', 'status', 'jaminan', 'denda', 'jatuh_tempo', 'konfirmasi', 'pembatalan'];

    public function getRiwayatTransaksi($id_pelanggan)
    {
        return $this->db->table('transaksi')
            ->where('id_pelanggan ', $id_pelanggan)
            ->get();
    }

    public function getRiwayatDenda($id_pelanggan)
    {
        return $this->db->table('transaksi')
            ->where('id_pelanggan ', $id_pelanggan)
            ->where('denda <>', '')
            ->get();
    }

    public function getKonfirmasi($start, $stop)
    {
         return $this->db->table('transaksi')
             ->join('pelanggan', 'transaksi.id_pelanggan = pelanggan.id')
             ->join('konfirmasi', 'transaksi.id = konfirmasi.id_transaksi')
             ->where('tgl_sewa >=', $start)
             ->where('tgl_sewa <=', $stop)
             ->get();
    }

    public function getPenyewaanPermobil($start, $stop)
    {
        return $this->db->table('transaksi')
            ->join('pelanggan', 'transaksi.id_pelanggan = pelanggan.id')
            ->join('mobil', 'transaksi.id_mobil = mobil.id')
            ->where('tgl_sewa >=', $start)
            ->where('tgl_sewa <=', $stop)
            ->get();
    }

    public function getSeringDenda($start, $stop)
    {
        return $this->db->table('transaksi')
            ->select('pelanggan.nama, (SELECT COUNT(transaksi.id)) AS jumlah')
            ->join('pelanggan', 'transaksi.id_pelanggan = pelanggan.id')
            ->where('denda <>', '')
            ->where('tgl_sewa >=', $start)
            ->where('tgl_sewa <=', $stop)
            ->get();
    }

    public function getPerperiode($start, $stop)
    {
        return $this->db->table('transaksi')
            ->join('pelanggan', 'transaksi.id_pelanggan = pelanggan.id')
            ->join('mobil', 'transaksi.id_mobil = mobil.id')
            ->where('tgl_sewa >=', $start)
            ->where('tgl_sewa <=', $stop)
            ->get();
    }

    public function getTerlaris($start, $stop)
    {
        return $this->db->table('transaksi')
            ->select('SELECT m.no_mobil, m.merk, m.nama_mobil, (SELECT COUNT(*) FROM transaksi WHERE id_mobil=t.id_mobil) AS jml')
            ->join('mobil', 'transaksi.id_mobil = mobil.id')
            ->where('tgl_sewa >=', $start)
            ->where('tgl_sewa <=', $stop)
            ->get();
    }

    public function getDenda($start, $stop)
    {
        return $this->db->table('transaksi')
            ->select('pelanggan.nama, transaksi.total_harga, transaksi.denda, transaksi.tgl_sewa, transaksi.tgl_ambil, transaksi.tgl_kembali, (TIMESTAMPDIFF(HOUR, ADDDATE(transaksi.tgl_ambil, INTERVAL transaksi.lama DAY), transaksi.tgl_kembali)) AS terlambat')
            ->join('pelanggan', 'transaksi.id_pelanggan = pelanggan.id')
            ->where('denda !=', 0)
            ->where('tgl_sewa >=', $start)
            ->where('tgl_sewa <=', $stop)
            ->get();
    }

    public function getDetailTransaksi($id)
    {
        return $this->db->table('transaksi')
            ->join('pelanggan', 'transaksi.id_pelanggan = pelanggan.id')
            ->join('mobil', 'transaksi.id_mobil = mobil.id')
            ->where('id =', $id)
            ->get();
    }
}