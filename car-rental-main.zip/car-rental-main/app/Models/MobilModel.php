<?php

namespace App\Models;

use CodeIgniter\Model;

class MobilModel extends Model
{
    protected $table = 'mobil';
    protected $primaryKey = 'id';

    protected $useAutoIncrement = true;
    protected $allowedFields = ['id_jenis', 'no_mobil', 'merk', 'nama_mobil', 'gambar', 'harga', 'status'];
}