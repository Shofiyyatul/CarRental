<?php

namespace App\Models;

use CodeIgniter\Model;

class TendaModel extends Model
{
    protected $table = 'tenda';
    protected $primaryKey = 'id';

    protected $useAutoIncrement = true;
    protected $allowedFields = ['nama', 'merk', 'no_seri', 'gambar', 'harga', 'status'];
}